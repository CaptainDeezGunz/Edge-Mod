﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace Edge.Items.Weapons
{
    public class TrueStarCannon : ModItem
    {
        public override void SetDefaults()
        {
            item.name = "True Star Cannon";
            item.damage = 65;
            item.ranged = true;
            item.width = 40;
            item.height = 20;
            item.toolTip = "Shoots any kind of star";
            item.toolTip2 = "Not Fixed Yet";
            item.useTime = 15;
            item.useAnimation = 20;
            item.useStyle = 5;
            item.noMelee = true; //so the item's animation doesn't do damage
            item.knockBack = 4;
            item.value = 10000;
            item.rare = 3;
            item.useSound = 11;
            item.autoReuse = true;
            item.shoot = 10; //idk why but all the guns in the vanilla source have this
            item.shootSpeed = 16f;
            item.useAmmo = ProjectileID.FallingStar;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.StarCannon, 1);
            recipe.AddIngredient(ItemID.FallenStar, 20);
            recipe.AddTile(TileID.AdamantiteForge);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}
        // What if I wanted this gun to have a 38% chance not to consume ammo?
        /*public override bool ConsumeAmmo(Player player)
		{
			return Main.rand.NextFloat() > .38f;
		}*/

// What if I wanted it to work like Uzi, replacing regular bullets with High Velocity Bullets?
// Uzi/Molten Fury style: Replace normal Bullets with Highvelocity
/*public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
{
    if (type == ProjectileID.Bullet) // or ProjectileID.WoodenArrowFriendly
    {
        type = ProjectileID.BulletHighVelocity; // or ProjectileID.FireArrow;
    }
    return true; // return true to allow tmodloader to call Projectile.NewProjectile as normal
}*/

// What if I wanted it to shoot like a shotgun?
// Shotgun style: Multiple Projectiles, Random spread 
//public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
//{
    //int numberProjectiles = 4 + Main.rand.Next(2); // 4 or 5 shots
    //for (int i = 0; i < numberProjectiles; i++)
